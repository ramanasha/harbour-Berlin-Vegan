About 
This is a set of icon templates that attempts to assists icon creation of exact size for Sailfish� Apps. They are editable with vector shape editor such as Inkscape or Adobe�Illustrator�, or with image editors such as GIMP� or Photoshop�.

Quick instructions
From your vector or image editor program, open any Sailfish-Apps-icon-template with corresponding file format. Export your icon as PNG file format in dimension of 86x86 pixels. 
Please also refer to Sailfish-Apps-icon-story document for further design assistance. Rest of Sailfish Apps icons are also available as Sailfish-Apps-icon-library.zip

Disclaimer
This icon template set is licensed under Creative Commons version 3.0 (CC BY 3.0). You are not required to provide attribution to us, as you making cool apps is enough for us.
Jolla and Sailfish are trademarks or registered trademarks of Jolla Ltd. Inkscape is a trademark of The Inkscape Team. GIMP is a trademark owned by The GIMP Development Team. Adobe, Photoshop and Illustrator are either trademarks or registered trademarks of U.S. Adobe Systems Incorporated in the United States and other countries.
