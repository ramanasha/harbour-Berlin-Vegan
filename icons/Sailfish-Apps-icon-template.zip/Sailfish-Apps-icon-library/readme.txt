About 
This is a set of default icons for Jolla App launcher. 
Please use them along with Sailfish-Apps-icon-story document, Sailfish-Apps-icon-template and Sailfish-Apps-icon-library.

Disclaimer
This icon template set is licensed under Creative Commons version 3.0 (CC BY 3.0). You are not required to provide attribution to us, as you making cool apps is enough for us.
